<?php
include 'database.php';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Livraria</title>
<style>
  body {
    font-family: Arial;
    background-color: #f3f3f3;
    padding: 20px;
  }
  h1 {
    text-align: center;
  }
  form {
    margin-top: 20px;
    margin-bottom: 20px;
  }
  input {
    padding: 6px;
    margin: 4px;
  }
  button {
    padding: 6px 10px;
    background: #333;
    color: white;
    border: none;
    cursor: pointer;
  }
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th, td {
    border: 1px solid #aaa;
    padding: 8px;
  }
  th {
    background: #ddd;
  }
</style>
</head>
<body>

<h1>Cadastro de Livros</h1>

<h3>Adicionar novo livro</h3>
<form action="add_book.php" method="post">
  <input type="text" name="titulo" placeholder="Título" required>
  <input type="text" name="autor" placeholder="Autor" required>
  <input type="number" name="ano" placeholder="Ano" required>
  <button type="submit">Adicionar</button>
</form>

<h3>Lista de livros</h3>

<table>
  <tr>
    <th>ID</th>
    <th>Título</th>
    <th>Autor</th>
    <th>Ano</th>
    <th>Ação</th>
  </tr>

  <?php
  $livros = $db->query("SELECT * FROM livros ORDER BY id DESC");
  foreach ($livros as $livro) {
      echo "<tr>";
      echo "<td>".$livro['id']."</td>";
      echo "<td>".$livro['titulo']."</td>";
      echo "<td>".$livro['autor']."</td>";
      echo "<td>".$livro['ano']."</td>";
      echo "<td>
              <form action='delete_book.php' method='post' onsubmit='return confirmar()'>
                <input type='hidden' name='id' value='".$livro['id']."'>
                <button type='submit'>Excluir</button>
              </form>
            </td>";
      echo "</tr>";
  }
  ?>
</table>

<script>
  function confirmar(){
    return confirm("Deseja realmente excluir este livro?");
  }
</script>

</body>
</html>
