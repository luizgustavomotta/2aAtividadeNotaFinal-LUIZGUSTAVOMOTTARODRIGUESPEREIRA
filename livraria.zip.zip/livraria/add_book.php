<?php
include 'database.php';

$titulo = $_POST['titulo'];
$autor = $_POST['autor'];
$ano = $_POST['ano'];

$inserir = $db->prepare("INSERT INTO livros (titulo, autor, ano) VALUES (?, ?, ?)");
$inserir->execute([$titulo, $autor, $ano]);

header("Location: index.php");
exit;
?>
