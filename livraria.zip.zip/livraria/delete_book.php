<?php
include 'database.php';

$id = $_POST['id'];

$excluir = $db->prepare("DELETE FROM livros WHERE id = ?");
$excluir->execute([$id]);

header("Location: index.php");
exit;
?>
