<?php
// conexão com o banco de dados SQLite
$db = new PDO('sqlite:banco_livros.db');

// cria tabela se ainda não existir
$db->exec("CREATE TABLE IF NOT EXISTS livros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT,
    autor TEXT,
    ano INTEGER
)");
?>
